<?php
namespace app\controllers;
use app\views\View;
use app\services\GalleryService;
class AuthController extends Controller
{
    private $auth = null;
    public function __construct()
    {
        $config = config();
        $this->auth = json_decode(file_get_contents(ROOT_PATH.$config['DB_PATH'].'/user.json'));
    }

    public function indexAction()
    {
        View::render('/auth/login');
    }
    public function loginAction()
    {
        if($_SERVER['REQUEST_METHOD'] == 'POST')
        {
            if(empty($_POST['username']) and !empty($_POST['password']))
                redirect_to('/auth/login');
            $user = (array)$this->auth->user;
            if(array_diff_assoc($_POST,$user))
            {
                $_SESSION['error'] = 'Username or passwor is incorrect!';
                redirect_to('/auth/login');
            }
            $_SESSION['user'] = $user;
            $galleryService = new GalleryService();
            redirect_to('/gallery');
        }
        View::render('/auth/login');
    }

    public function logoutAction()
    {
        $_SESSION['user'] = null;
        redirect_to('/auth/login');
    }

}
