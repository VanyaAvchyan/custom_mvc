<?php
namespace app\controllers;
use app\views\View;
use app\services\GalleryService;
class GalleryController extends Controller
{
    public function __construct()
    {
        if(empty($_SESSION['user']))
            redirect_to('/auth/login');
    }

    public function indexAction()
    {
        $service = new GalleryService();
        View::render('galery/index', [
            'galleries' => $service->getAll()
        ]);
    }

    public function uploadAction()
    {
        if($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $_SESSION['error'] = 'Method not allowed';
            redirect_to('/gallery');
        }

        if(empty($_FILES['file']))
        {
            $_SESSION['error'] = 'File is empty !';
            redirect_to('/gallery');
        }

        $service = new GalleryService();
        $service->uploadFile($_FILES['file']);

        $_SESSION['error'] = "Success !";
        redirect_to('/gallery');
    }

    public function deleteAction($id = 0){
        $service = new GalleryService();
        $service->delete($id);
        redirect_to('/gallery');
    }
}