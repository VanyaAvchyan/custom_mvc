<?php
namespace app\services;
use app\models\GalleryModel;
class GalleryService {
    private $model;
    public function __construct() {
        $this->model = new GalleryModel();
    }

    public function getAll()
    {
        return $this->model->data;
    }

    public function delete($id)
    {
        $data = (array)$this->model->data;
        if(!empty($data[$id]))
        {
            unset($data[$id]);
            $this->model->save($data);
            return true;
        }
        return false;
    }


    public function uploadFile($file)
    {
        $errors = '';
        $file_name = $file['name'];
        $file_ext = pathinfo($file_name, PATHINFO_EXTENSION);
        $file_unique_name = uniqid().'.'.$file_ext;

        $file_size = $file['size'];
        $file_tmp  = $file['tmp_name'];
        $file_type = $file['type'];

        $file_ext = strtolower(end(explode('.',$file['name'])));

        $extensions= array("jpeg","jpg","png");

        if(in_array($file_ext,$extensions)=== false){
            $errors .="Extension not allowed, please choose a JPEG or PNG file.<br>";
        }

        if($file_size > 2097152){
            $errors .='File size must be excately 2 MB<br>';
        }

        $file = ROOT_PATH."uploads/".$file_unique_name;
        move_uploaded_file($file_tmp, $file);

        // Save into json
        $this->model->data[] = [
            'name' => $file_name,
            'file' => $file_unique_name
        ];
        $this->model->save($this->model->data);
        return !$errors;
    }


}