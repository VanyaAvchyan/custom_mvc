<?php if(!empty($_SESSION['error'])) : ?>
    <div class="alert alert-danger">
        <?=$_SESSION['error'];?>
        <?php $_SESSION['error'] = '';?>
    </div>
<?php endif; ?>
<h1>Upload files</h1>
<form action="/gallery/upload" method="POST" enctype="multipart/form-data">
    <div class="form-group">
        <input type="file" name="file" class="col-md-3">
        <button type="submit" class="btn btn-primary">Upload</button>
    </div>
</form>

<h2>List</h2>
<table class="table">
    <thead>
    <tr>
        <th>ID</th>
        <th>Name</th>
        <th>Image</th>
        <th>Actions</th>
    </tr>
    </thead>
    <tbody>
    <?php

    foreach ($galleries as $id => $gallery): ?>
        <tr>
            <td><?= $gallery->id; ?></td>
            <td><?= $gallery->name; ?></td>
            <td><img src="/uploads/<?= $gallery->file; ?>" width="200"/></td>
            <td><a href="/gallery/delete/id/<?=$id?>">Delete</a> </td>
        </tr>
    <?php endforeach; ?>
    </tbody>
</table>