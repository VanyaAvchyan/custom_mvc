<?php
namespace app\models;
class GalleryModel extends \app\models\Model
{

    public function save($data)
    {
        $config = config();
        $data = json_encode($data);
        $file = ROOT_PATH.$config['DB_PATH'].'/gallery.json';
        file_put_contents($file, $data);
    }

}