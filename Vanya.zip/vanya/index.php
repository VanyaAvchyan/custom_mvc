<?php
define('ROOT_PATH', __DIR__ . DIRECTORY_SEPARATOR);
session_start();
include 'autoload.php';
\app\Application::getInstance()->render();
